var mongoose = require('mongoose');
var Loc = mongoose.model('Location');

var sendJSONresponse = function(res, status, content) {
  res.status(status);
  res.json(content);
};

/* /api/locations */
module.exports.reviewsCreate = function(req, res) 
{
     sendJSONresponse(res, 200, {"status" : "sucess"});
 } 

module.exports.reviewsReadOne = function(req, res) 
{
    sendJSONresponse(res, 200, {"status" : "sucess"});
 } 

module.exports.reviewsUpdateOne = function(req, res) 
{
  sendJSONresponse(res, 200, {"status" : "sucess"});
 } 

module.exports.reviewsDeleteOne = function(req, res) 
{
    sendJSONresponse(res, 204, {"status" : "sucess"});
 } 
