var mongoose = require('mongoose');
var Loc = mongoose.model('Location');

var sendJSONresponse = function(res, status, content) {
  res.status(status);
  res.json(content);
};

/* /api/locations */
module.exports.locationsListByDistance = function(req, res) 
{
     sendJSONresponse(res, 200, {"status" : "sucess"});
 } 

module.exports.locationsCreate = function(req, res) 
{
     sendJSONresponse(res, 200, {"status" : "sucess"});p
 } 

module.exports.locationsReadOne = function(req, res) 
{
    sendJSONresponse(res, 200, {"status" : "sucess"});
 } 

module.exports.locationsUpdateOne = function(req, res) 
{
   sendJSONresponse(res, 200, {"status" : "sucess"});
 } 

module.exports.locationsDeleteOne = function(req, res) 
{
sendJSONresponse(res, 200, {"status" : "sucess"});
 } 
