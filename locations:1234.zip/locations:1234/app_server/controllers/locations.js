/* GET 'home' page */
/*'home' page */
module.exports.homelist = function(req, res) {
    res.render('locations-list', {
        title: 'Moviepedia',
        pageHeader: {
            title: 'Moviepedia',
            strapline: 'Encyclopedia For Movies'
        },
        sidebar: "Looking for information about a certain movie? you've come to the correct place, Moviepedia helps you find about it in detail.",

        locations: [{
            Name: 'The Avengers',
            Starring: 'Robert Downey Jr, Chris Evans, Mark Ruffalo,Chris Hemsworth, Scarlett Johansson,Jeremy Renner,Tom Hiddleston,Clark Gregg, Cobie Smulders, Stellan Skarsgård, Samuel L. Jackson',
            Rating: 3,
            Genre: ['Action', 'Suspence'],
            Released: 'April 11, 2012'
                     }, 
        {
            Name: 'The Flash',
            Starring: 'Grant Gustin, Candice Patton, Danielle Panabaker, Rick Cosnett, Carlos Valdes, Tom Cavanagh, Jesse L. Martin, Keiynan Lonsdale',
            Rating: 4,
            Genre: ['Superhero fiction', 'Action', 'Mystery'],
            Released: '	October 7, 2014'
        }, 
        {
            Name: 'Justice League',
            Starring: 'Ben Affleck, Henry Cavill,Amy Adams,Gal Gadot,Jason Momoa,Ezra Miller,Ray Fisher,Willem Dafoe,Jesse Eisenberg,Jeremy Irons,Diane Lane,Connie Nielsen,J. K. Simmons',
            Rating: 5,
            Genre: ['Superhero fiction', 'Action', 'Mystery'],
            Released: 'November 17, 2016'
        }]
    });
};

/* GET 'Location info' page */
/*avengers*/

module.exports.locationInfo = function(req, res) {
    res.render('location-info', {
        title: 'The Avengers',
        pageHeader: {
            title: 'The Avengers'
        },
        sidebar: {
            context: 'Earth\'s mightiest heroes must come together and learn to fight as a team if they are to stop the mischievous Loki and his alien army from enslaving humanity.',
            callToAction: 'If you\'ve been and you like it - or if you don\'t - please leave a review to help other people just like you.'
        },
        location: {
            name: 'The Avengers',
            Starring: 'Robert Downey Jr, Chris Evans, Mark Ruffalo,Chris Hemsworth, Scarlett Johansson,Jeremy Renner,Tom Hiddleston,Clark Gregg, Cobie Smulders, Stellan Skarsgård, Samuel L. Jackson',
            Rating: 3,
            Genre: ['Action', 'Mystery'],
            coords: {
                lat: 51.455041,
                lng: -0.9690884
            },
            openingTimes: [{
                days: 'Monday - Friday',
                opening: '7:00am',
                closing: '7:00pm',
                closed: false
            }, {
                days: 'Saturday',
                opening: '8:00am',
                closing: '5:00pm',
                closed: false
            }, {
                days: 'Sunday',
                closed: true
            }],

            
            reviews: [{
                author: 'Doctor Who',
                rating: 5,
                timestamp: '08 July 2013',
                reviewText: 'What a great place. I can\'t say enough good things about it.'
            }, {
                author: 'Wonder Women',
                rating: 3,
                timestamp: '16 June 2013',
                reviewText: 'It was okay. Coffee wasn\'t great, but the wifi was fast.'
            }]
        }
    });
};
/* GET 'Add review' page */
module.exports.addReview = function(req, res) {
    res.render('location-review-form', {
        title: 'Review The Avengers on Moviepedia',
        pageHeader: {
            title: 'Review The Avengers'
        }
    });
};


/* GET 'Location info' page */
/*The Flash*/

module.exports.locationInfo = function(req, res) {
    res.render('location-info', {
        title: 'The Flash',
        pageHeader: {
            title: 'The Flash'
        },
        sidebar: {
            context: 'After being struck by lightning, Barry Allen wakes up from his coma to discover he\'s been given the power of super speed, becoming the Flash, fighting crime in Central City.',
            callToAction: 'If you\'ve been and you like it - or if you don\'t - please leave a review to help other people just like you.'
        },
        location: {
            name: 'The Flash',
           Starring: 'Grant Gustin, Candice Patton, Danielle Panabaker, Rick Cosnett, Carlos Valdes, Tom Cavanagh, Jesse L. Martin, Keiynan Lonsdale',
            Rating: 4,
            Genre: ['Superhero fiction', 'Action', 'Mystery'],
            coords: {
                lat: 51.455041,
                lng: -0.9690884
            },
            openingTimes: [{
                days: 'Monday - Friday',
                opening: '7:00am',
                closing: '7:00pm',
                closed: false
            }, {
                days: 'Saturday',
                opening: '8:00am',
                closing: '5:00pm',
                closed: false
            }, {
                days: 'Sunday',
                closed: true
            }],

            reviews: [{
                author: 'Doctor ',
                rating: 5,
                timestamp: '16 July 2013',
                reviewText: 'What a great place. I can\'t say enough good things about it.'
            }, {
                author: 'Wonder ',
                rating: 3,
                timestamp: '16 June 2013',
                reviewText: 'It was okay. Coffee wasn\'t great, but the wifi was fast.'
            }]
        }
    });
};
/* GET 'Add review' page */
module.exports.addReview = function(req, res) {
    res.render('location-review-form', {
        title: 'Review The Avengers on Moviepedia',
        pageHeader: {
            title: 'Review The Avengers'
        }
    });
};

/* GET 'Location info' page */
/*Justice League*/

module.exports.locationInfo = function(req, res) {
    res.render('location-info', {
        title: 'Justice League',
        pageHeader: {
            title: 'Justice League'
        },
        sidebar: {
            context: 'Fueled by his restored faith in humanity and inspired by Superman\'s selfless act, Bruce Wayne enlists the help of his newfound ally, Diana Prince, to face an even greater enemy.',
            callToAction: 'If you\'ve been and you like it - or if you don\'t - please leave a review to help other people just like you.'
        },
        location: {
            name: 'Justice League',
           Starring: 'Ben Affleck, Henry Cavill,Amy Adams,Gal Gadot,Jason Momoa,Ezra Miller,Ray Fisher,Willem Dafoe,Jesse Eisenberg,Jeremy Irons,Diane Lane,Connie Nielsen,J. K. Simmons',
            Rating: 5,
            Genre: ['Superhero fiction', 'Action', 'Mystery'],
            coords: {
                lat: 51.455041,
                lng: -0.9690884
            },
            openingTimes: [{
                days: 'Monday - Friday',
                opening: '7:00am',
                closing: '7:00pm',
                closed: false
            }, {
                days: 'Saturday',
                opening: '8:00am',
                closing: '5:00pm',
                closed: false
            }, {
                days: 'Sunday',
                closed: true
            }],

            reviews: [{
                author: 'Doctor ',
                rating: 5,
                timestamp: '16 July 2013',
                reviewText: 'What a great place. I can\'t say enough good things about it.'
            }, {
                author: 'Wonder ',
                rating: 3,
                timestamp: '16 June 2013',
                reviewText: 'It was okay. Coffee wasn\'t great, but the wifi was fast.'
            }]
        }
    });
};
/* GET 'Add review' page */
module.exports.addReview = function(req, res) {
    res.render('location-review-form', {
        title: 'Review The Avengers on Moviepedia',
        pageHeader: {
            title: 'Review The Avengers'
        }
    });
};

